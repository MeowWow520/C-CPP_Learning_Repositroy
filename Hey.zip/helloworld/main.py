from astrbot.api.event import filter, AstrMessageEvent, MessageEventResult
from astrbot.api.star import Context, Star, register
from astrbot.api import logger

@register("Hey", "MeowWow520", "一个提示插件", "1.0.0", "blog.MeowWow520.cn")
class MyPlugin(Star):
    def __init__(self, context: Context):
        super().__init__(context)
    
    # 注册指令的装饰器。指令名为 helloworld。注册成功后，发送 `/helloworld` 就会触发这个指令
    @filter.command("Hey")
    async def helloworld(self, event: AstrMessageEvent):
        '''这是一个提示插件''' # 这是 handler 的描述，将会被解析方便用户了解插件内容。建议填写。
        user_name = event.get_sender_name()
        message_str = event.message_str # 用户发的纯文本消息字符串
        message_chain = event.get_messages() # 用户所发的消息的消息链 # from astrbot.api.message_components import *
        logger.info(message_chain)
        yield event.plain_result("""\n
你好！欢迎使用 AstrBot。本机器人使用 DeepSeek-R1 作为模型，调用深度求索官方api接口。以下是本bot的食用方法：
        
/Hey：发送本条消息
/sysinfo：显示系统信息
/persona：切换人格场景 (Just For Op)。如需要联系2673655285切换人格                         

/setu：发送一张随机涩图
/taisele：发送一张随机R18涩图   

/搜番：以图搜番
/moe：调用随机动漫图片
/mcs:<minecraft服务器地址>：查询MC服务器状态 (暂时不可用？)
/一言：调用一言
/今天吃什么：随机返回一个食物名称
/喜加一：EPIC喜加一
/早安 or /晚安：在群里发早晚安，记录睡眠时长，保持健康！

/今日老婆：随机配对CP
/查询老婆：查询当前CP
/我要分手：解除当前CP关系

/ping：测试网址连通性
/siteno：测试网址连通性    
/whois：查询指定域名的whois信息
/site：截图指定网址 (暂时不可用？)        
        
更多命令正在添加中！
Powered By AstrBot v.3.4.32
Made By MeowWow520
        """) # 发送一条纯文本消息